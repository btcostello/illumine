import React from 'react';
import { FaLightbulb } from "react-icons/fa";
import {
  Nav,
  NavLink,
  Bars,
  NavMenu,
  NavBtn,
  NavBtnLink,
} from './NavbarElements';
  
const Navbar = () => {
  return (
    <>
      <Nav>
        <Bars />
  
        <NavMenu>
          <NavLink to='/' >
          <FaLightbulb/>
          </NavLink>
          <NavLink to='/about' >
            About
           </NavLink>
          <NavLink to='/services' >
            Services
          </NavLink>
          <NavLink to='/pricing' >
            Pricing
          </NavLink>
          <NavLink to='/tutorial' >
            Tutorial
          </NavLink>
         {/* <NavLink to='/insights' activeStyle>
            Insights
          </NavLink>*/}

           <NavLink to='/calculator' >
            Calculator
           </NavLink>
          {/* Second Nav */}
          {/* <NavBtnLink to='/sign-in'>Sign In</NavBtnLink> */}
          
        </NavMenu>
        <NavBtn>
          <NavBtnLink to='/signin'>Account</NavBtnLink>
        </NavBtn>
      </Nav>
    </>
  );
};
  
export default Navbar;