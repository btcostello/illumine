import React from "react";

export function Footer() {
  return (
    <div className="footer">
      <footer>
        <div className="container">
          <p>
            Copyright &copy; Illumine LLC 2022
          </p>
        </div>
      </footer>
    </div>
  );
}
