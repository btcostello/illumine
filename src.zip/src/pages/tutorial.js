
import React from 'react';

const Tutorial = () => {
  return (
    <div>
      <h1>Illumine is fast and easy to use</h1>
      <h2>1. Enter policy information</h2>

      <h2>2. Calibrate the model</h2>
      
      <h2>3. Run the analysis</h2>
      <p>Create an account to get started</p>
    </div>  
  );
};
  
export default Tutorial;