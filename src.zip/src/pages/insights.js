import React from 'react';

  
const Insights = () => {
  return (
    <div
      style={{
        justifyContent: 'Left',
        alignItems: 'Left',
        height: '100vh',
      }}
    >
      <h1>Insights</h1>
      <p>Our articles go here</p>
    </div>
  );
};
  
export default Insights;