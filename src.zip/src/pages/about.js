
import React from 'react';

const About = () => {
  return (
    <div
      style={{
        height: '100vh',
            }}
    >
      <h1>We created Illumine to bring clarity to complex life insurance policies</h1>
      <p>Illumine was founded by a group of insurance professionals...</p>

      <p>Disclosures</p>
      <p>Privacy Policy</p>

    </div>  
  );
};
  
export default About;