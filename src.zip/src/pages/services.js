import React from 'react';
  
const Services = () => {
  return (
    <div
      style={{
        justifyContent: 'Left',
        alignItems: 'Left',
        height: '100vh',
      }}
    >
      <h1>Illumine Services</h1>
      <ul>
        <li>Policy analysis calculators</li>
        <li>Case consulting</li>
        <li>Due diligence for trustees</li>
        <li>Financed policy analysis and implementation</li>
      </ul>
    </div>
  );
};
  
export default Services;