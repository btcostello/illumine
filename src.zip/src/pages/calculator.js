import { Sex, ProductButton, ChargeDial, EarlyDial, LateDial, Smoker } from '../Buttons';
import { Card, Authenticator } from '@aws-amplify/ui-react'
import React from 'react'

import Chart from "chart.js/auto";
import { CategoryScale } from "chart.js";
import LineChart from "../components/AVChart/index";
import { PremAmt, PremYrs, FaceAmt } from '../components/NumInputs';
import { Prob } from '../components/Probability'


Chart.register(CategoryScale);


const Calculator = () => {


    return (
        <Authenticator>

        <div className="App">

        <h1>Illumine Probability Calculator</h1>
        <div className="CalcContainer"> 
            <div className="flexInputs">
            <Card className="button" variation="elevated"><ProductButton/></Card>
            <Card className="button" variation="elevated"><Sex/></Card>
            <Card className="button" variation="elevated"><Smoker/></Card>
            <Card ClassName="button" variation="elevated"><PremAmt/></Card>
            <Card ClassName="button" variation="elevated"><PremYrs/></Card>
            <Card ClassName="button" variation="elevated"><FaceAmt/></Card>
            </div>
            <div className="flexCalibration">
            <Card ClassName="button" variation="elevated">
                <ChargeDial/>
                <EarlyDial/>
                <LateDial/>
            </Card>
            </div>
            <div className="flexChart">
            <Card variation="elevated">
                <LineChart/>
            </Card>
            </div>
        </div>  
        <Card variation="elevated">
            <Prob/>
        </Card>

        </div>
        <p className="Release"> Beta Release v0.0.10</p>
        </Authenticator>
)}

export default Calculator;
