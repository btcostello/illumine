import React from 'react';
  
const Home = () => {
  return (
    <div
      style={{
        justifyContent: 'Left',
        alignItems: 'Left',
        height: '100vh',
      }}
    >
      <h1>llumine</h1>
      <p>Transform the way you look at life insurance</p>
    </div>
  );
};
  
export default Home;