export const IntroBC = { 
    textAlign: "left", 
    fontSize: 20
}

